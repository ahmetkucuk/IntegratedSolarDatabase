# SolarDatabaseServer
A try for Solar Database API with Golang on Beego

Requirements: 

Golang

Beego       -> see beego installation instructions (https://github.com/goinggo/beego-mgo)

pl (postgres)    -> go get github.com/lib/pq


Then, you need to put the project under the golang workspace folder.

Under the GOPATH=$HOME/work/src

To run, use "bee run" command.
